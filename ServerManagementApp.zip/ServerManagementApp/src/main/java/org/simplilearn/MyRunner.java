package org.simplilearn;

import org.simplilearn.entities.Server;
import org.simplilearn.repositories.ServerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

//@Component
public class MyRunner implements CommandLineRunner{
	@Autowired
	private ServerRepository serverRepository;
	@Override
	public void run(String... args) throws Exception {
		Server server1=new Server();
		server1.setName("Test Server");
		server1.setStatus("Online");
		Server server2=new Server();
		server2.setName("Prod Server");
		server2.setStatus("Offline");
		Server server3=new Server();
		server1.setName("Dev Server");
		server1.setStatus("Online");
		serverRepository.save(server1);
		serverRepository.save(server2);
		serverRepository.save(server3);
	}

}
