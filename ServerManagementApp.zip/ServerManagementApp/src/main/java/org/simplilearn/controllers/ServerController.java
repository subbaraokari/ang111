package org.simplilearn.controllers;

import java.util.List;

import org.simplilearn.entities.Server;
import org.simplilearn.services.ServerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/api/servers")
public class ServerController {
	private ServerService serverService;
	public ServerController(ServerService serverService) {
		super();
		this.serverService = serverService;
	}
	@PostMapping
	public ResponseEntity<Server> insertServer(@RequestBody Server server){
		this.serverService.insertServer(server);
		return new ResponseEntity<Server>(server, HttpStatus.CREATED);
	}
	@GetMapping
	public ResponseEntity<List<Server>> getServers(){
		List<Server> servers=this.serverService.getServers();
		return new ResponseEntity<List<Server>>(servers, HttpStatus.OK);
	}
	@DeleteMapping("/delete/{sid}")
	public ResponseEntity<Server> deleteServer(@PathVariable("sid") int sid){
		Server server=this.serverService.getServer(sid);
		this.serverService.deleteServer(sid);
		return new ResponseEntity<Server>(server, HttpStatus.OK);
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/get/{sid}")
	public ResponseEntity<Server> getServer(@PathVariable("sid") int sid){
		Server server=this.serverService.getServer(sid);
		return new ResponseEntity<Server>(server, HttpStatus.OK);
	}
	@PutMapping("/update/{sid}")
	public ResponseEntity<Server> updateServer(@PathVariable("sid") int sid,@RequestBody Server server){
		serverService.update(sid, server);
		return new ResponseEntity<Server>(server, HttpStatus.OK);
	}
	
}
