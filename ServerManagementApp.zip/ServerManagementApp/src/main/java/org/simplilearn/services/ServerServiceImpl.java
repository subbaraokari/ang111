package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Server;
import org.simplilearn.repositories.ServerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServerServiceImpl implements ServerService{
	@Autowired
	private ServerRepository serverRepository;
	@Override
	public void insertServer(Server server) {
		serverRepository.save(server);
	}

	@Override
	public void deleteServer(int sid) {
		serverRepository.deleteById(sid);
	}

	@Override
	public List<Server> getServers() {
		return serverRepository.findAll();
	}

	@Override
	public Server getServer(int sid) {
		return serverRepository.findById(sid).get();
	}

	@Override
	public void update(int sid, Server server) {
		Server server1=serverRepository.findById(sid).get();
		server1.setName(server.getName());
		server1.setStatus(server.getStatus());
		serverRepository.save(server1);
	}

}
