package org.simplilearn.services;

import java.util.List;

import org.simplilearn.entities.Server;

public interface ServerService {
	void insertServer(Server server);
	void deleteServer(int sid);
	List<Server> getServers();
	Server getServer(int sid);
	void update(int sid,Server server);
}
