import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ServerModel } from "../models/server.model";

@Injectable({
    providedIn:'root'
})
export class ServerService{
    constructor(private httpClient:HttpClient){

    }
    getServers():Observable<ServerModel[]>{
        return this.httpClient.get<ServerModel[]>('http://localhost:8080/api/servers');
    }
    getServer(id:number):Observable<ServerModel>{
        return this.httpClient.get<ServerModel>(`http://localhost:8080/api/servers/get/${id}`);
    }
    updateServer(id:number,server:ServerModel):Observable<ServerModel>{
        return this.httpClient.put<ServerModel>(`http://localhost:8080/api/servers/update/${id}`,server);
    }
}   