export interface ServerModel{
    id:number;
    name:string;
    status:string;
}