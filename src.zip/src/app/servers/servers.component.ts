import { Component,OnInit } from '@angular/core';
import { ServerModel } from '../models/server.model';
import { ServerService } from '../services/server.service';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit{
  servers:ServerModel[];
  constructor(private serverService:ServerService){
   }
   ngOnInit(): void {
       this.serverService.getServers().subscribe((servers:ServerModel[])=>{
          this.servers=servers;
       });
   }
}
