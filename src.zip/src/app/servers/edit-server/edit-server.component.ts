import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { ServerModel } from 'src/app/models/server.model';
import { ServerService } from 'src/app/services/server.service';

@Component({
  selector: 'app-edit-server',
  templateUrl: './edit-server.component.html',
  styleUrls: ['./edit-server.component.css'],
})
export class EditServerComponent implements OnInit {
  allowEdit:string;
  serverName: string;
  status: string;
  constructor(
    private route: ActivatedRoute,
    private serverService: ServerService
  ) {}
  ngOnInit(): void {
    this.route.params.subscribe((params:Params)=>{
      let id=+params['id'];
      this.serverService.getServer(id).subscribe((server:ServerModel)=>{
          this.serverName=server.name;
          this.status=server.status;
      });
    });
    this.route.queryParams.subscribe((params:Params)=>{
        this.allowEdit=params['allowEdit'];
    });
  }
  onUpdate(){
    let id;
    this.route.params.subscribe((params=>{
      id=+params['id'];
    }))
    let server:ServerModel={
      id:id,
      name:this.serverName,
      status:this.status
    };
    this.serverService.updateServer(id,server).subscribe(resp=>{
      console.log(resp);
    });
  }
}
