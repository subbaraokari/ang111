import { Component,OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ServerModel } from 'src/app/models/server.model';
import { ServerService } from 'src/app/services/server.service';

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
  styleUrls: ['./server.component.css']
})
export class ServerComponent implements OnInit{
  server:ServerModel;
  constructor(private route:ActivatedRoute,private router:Router,private serverService:ServerService){

  }
  ngOnInit(){
      this.route.params.subscribe((params:Params)=>{
          let id=+params['id'];
          console.log(id);
          this.serverService.getServer(id).subscribe((server:ServerModel)=>{
            this.server=server;
          });
      });
  }
  onEdit(){
    this.router.navigate(['edit'],{relativeTo:this.route,queryParamsHandling:'preserve'});
  }
}
